  "instruction not supported on selected architecture",ERROR,
  "trailing garbage in operand",WARNING,
  "selector prefix ignored",WARNING,
  "data size %d not supported",ERROR,
  "operand doesn't fit into %d bits",WARNING,
  "branch destination out of range",ERROR,                            /* 05 */
  "illegal bit number",ERROR,
  "identifier expected",ERROR,
  "operand not in direct-page range",ERROR,
  "unsuitable addressing mode for retrieving memory id",ERROR,
  "no memory id defined, assuming 0",WARNING,                         /* 10 */
