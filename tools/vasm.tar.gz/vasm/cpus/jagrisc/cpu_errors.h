  "data size %d not supported",ERROR,
  "value from %d to %d required",ERROR,
  "register expected",ERROR,
